import Foundation
import CryptoKit

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true
    guard let url = urlRequest else { return }
    URLSession.shared.dataTask(with: url) { data, response, error in
        if error != nil {
            print("error: \(error?.localizedDescription ?? "")")
        } else if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            print("response: \(response.statusCode)")
            
            guard let data = data else  { return }
            let dataAsString = String(data: data, encoding: .utf8)
            print("\(String(describing: dataAsString))")
        }
    }.resume()
}

extension String {
    func md5() -> String {
        return Insecure.MD5.hash(data: self.data(using: .utf8) ?? Data()).map { String(format: "%02hhx", $0) }.joined()
    }
}

let apiKey = "80ebd9295fe3018c9806ef55164dfbb2"
let privateKey = "25ce5560435f45c43095e1e796c8064b53f40808"
let timestamp = 1
let hashMd5 = "\(timestamp)\(privateKey)\(apiKey)".md5()
let urlMarvel = "https://gateway.marvel.com/v1/public/stories?ts=\(timestamp)&apikey=\(apiKey)&hash=\(hashMd5)"

getData(urlRequest: urlMarvel)
